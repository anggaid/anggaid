<!-- this script is free for all not for sale
	 Owner 	: Ahmad Zulfi
	 Date 	: 11/12/2-16
 -->
<!DOCTYPE html>
<html>
<head>
	<title>Auto Like random by mr.n0p3c</title>
	<meta name="keywords" content="auto like instagram">
    <meta name="author" content="Mr.n0p3C a.k.a wrench">
    <script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/zeeb.js"></script>
</head>
<body>
<div id="hasil"></div>
<input type="text" id="url" name="url" placeholder="https://www.instagram.com/p/BL4zeA0ABZ9" size="40px">
<br>
<input type="button" id="kirim" name="kirim" value="kirim">
</body>
</html>